<?php
session_start();
$localhost="localhost";
$name="root";
$password="";
$error="";

$con=mysqli_connect($localhost,$name,$password,"anu")or die("Not connected");
   $pass= $_POST['pass'];
    $email=$_POST['email'];
        $query="select * from login where email='$email' and pass='$pass'";
        $result=mysqli_query($con,$query);
        
        
        $n=mysqli_num_rows($result);
       
        if($n>0){
            $_SESSION['user']=$email;
         header('Location:bytes.php');
        }
        else{
            echo "invaid details";
            header('Location:login.php');
     
    }
 

mysqli_close($con);

?>