<?php
$localhost="localhost";
$name="root";
$password="";
$error="";

$con=mysqli_connect($localhost,$name,$password,"anu")or die("Not connected");
$name=$_GET['name'];
$email=$_GET['email'];
$phone=$_GET['phone'];
$job=$_GET['job'];
$pass=$_GET['pass'];
$pass1=$_GET['pass1'];
if (isset($_GET['submit'])){
if(!$pass1==""){
if($pass===$pass1){
    $query="insert into login values('".$name."','".$email."','".$phone."','".$job."','".$pass."')";
    $result=mysqli_query($con,$query);
    
    $n=mysqli_affected_rows($con);
   
    if($n=true){
     header('Location:login.php');
    }
    else{
        $error="invaid details";
    }
}
 
}
}
else if (isset($_GET['LogIn'])){
    
    
        $query="select email,password from login where email=$email and password=$pass";
        $result=mysqli_query($con,$query);
        
        $n=mysqli_affected_rows($con);
       
        if($query){
         header('Location:bytes.php');
        }
        else{
            $error="invaid details";
            echo "invaid details";
     
     
    }
    }

mysqli_close($con);

?>