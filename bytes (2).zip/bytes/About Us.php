<!DOCTYPE html>
<html>
<Head>
<meta charset="UTF-8"/>
<title>Bytes computers</title>
<link rel="stylesheet" href="bytes.css">
</head>
<body>
<script>
alert("welcome to bytes computers About us page")
</script>
<header>
<h1>Bytes Computers Cyber</h1>
</header><br>
<div id="wrapper">
<nav>
<b><a href="Bytes.html">Home</a>&nbsp;
<a href="Services.html">Service</a>&nbsp;
<a href="About Us.html">About Us</a>&nbsp;
<a href="Course Application.html">Course Application</a>&nbsp;
<a href="contact.html">Contact</a>
</b>
</nav>
<div id="content"> 
<main>
<h2>Geographical Location</h2>
<ul>
<p>Bytes Computers is located at <li>Meru County</li><li>Imenti South Constituency</li><li>Igoji East Ward</li><li>Keeria Market next to Waiyaki's Shop</li></p>   
</main>
</div>
<h3>New Bytes Computers Logo</h3>
<h3><img src="image/computer 3.png" alt="structure of logo" Width="80" height="80"></h3>
<footer>
<footer>
<div id="footer">
<li><small> <p align="center"> copyright &copy 2016 bytes computers<p></li></small>
<div id="ima"><li><img src="image\3.jpg" height="20px" width="22px">Tel:0704881573</li>
<li><img src="image\2.jpg" height="20px" width="22px">Facebook:Bytes Computers</div>
<div id="ime"><li><img src="image\1.jpg" height="20px" width="22px">Instagram:@Bytes Computers</li>
<li><img src="image\4.png" height="20px" width="22px">
<a href="bytescomputers855@gmail.com">bytescomputers855@gmail.com</a></P>
</footer>
</footer>
</body>
</html>