<?php
//conection to database
$conn=mysqli_connect("localhost","root","","tesco");
//check connection_aborted
  if($conn){	
  $name=($_POST['name']);
  $city=($_POST['city']);

 

  
  //save the data into table
  if(isset($_POST['add'])){ 

 
  $q="insert into salesman(salesman_id,name,city)
    VALUES(null,'$name','$city')";
	//process the querry
	$q=mysqli_query($conn,$q);
	
	//
	if($q){
		header('Location:salesman.php');
	}
	else{
		echo "query failed tp add Order";
}

}
if(isset($_POST['update'])){
$q = "UPDATE `salesman` SET `name`=$name,`city`=$city  WHERE `salesman_id`=$salesman_id";

if (mysqli_query($conn, $q)) {
	header('Location:salesman.php');
	echo $q;
} else {
	
    echo "Error updating record: " . mysqli_error($conn);
}}
if(isset($_POST['del'])){
	$q = "DELETE FROM `salesman` WHERE `salesman_id`='$salesman_id'";
	echo $q;
	if (mysqli_query($conn, $q)) {
		header('Location:salesman.php');
	
	} else {
		
		echo "Error updating record: " . mysqli_error($conn);
	}}
}
$conn->close();

?>