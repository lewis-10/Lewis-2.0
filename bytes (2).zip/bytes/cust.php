<?php

//conection to database
$conn=mysqli_connect("localhost","root","","tesco");
//check connection_aborted
  if($conn){
  $customer_id=($_POST['customer_id']);  	
  $cust_name=($_POST['cust_name']);
  $city=($_POST['city']);
  $grade=($_POST['grade']);
  $salesman_id=($_POST['salesman_id']);

  
  //save the data into table
  if(isset($_POST['add'])){ 

 
  $k="insert into customer(cust_name,city,grade,salesman_id)
    VALUES('$cust_name','$city','$grade','$salesman_id')";
	
	//process the querry
	$k=mysqli_query($conn,$k);
	
	//
	if($k){
		header('Location:customers.php');
	}
	else{
		echo "query failed to add Order";
}

}
if(isset($_POST['update'])){
$q = "UPDATE `customer` SET `cust_name`='$cust_name',`city`='$city',salesman_id='$salesman_id' ,`grade` ='$grade' WHERE `customer_id`='$customer_id'";
echo $q;
if (mysqli_query($conn, $q)) {
	header('Location:customers.php'); 

} else {
	
    echo "Error updating record: " . mysqli_error($conn);
}}
if(isset($_POST['del'])){
	$q = "DELETE FROM `customer` WHERE `customer_id`='$customer_id'";
	echo $q;
	
	if (mysqli_query($conn, $q)) {
		header('Location:customers.php');
	
	} else {
		
		echo "Error updating record: " . mysqli_error($conn);
	}}
}
$conn->close();
?>