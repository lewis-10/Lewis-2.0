<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!DOCTYPE html>
<?php
error_reporting(0);
require 'php.php';?> 
<!DOCTYPE html>
<html>
<Head>

<title> Bytes supermarket</title>
<link rel="stylesheet" href="bytes.css">
</head>
<body>
<header>
<h1>Bytes supermarket</h1>
</header>
<div id="wrapper">
<nav>
<b><b><a href="bytes.php">Home</a>&nbsp;
<a href="Customers.php">Customers</a>&nbsp;
<a href="index2.php">Orders</a>&nbsp;
<a href="Salesman.php">Salesman</a>&nbsp;
<a href="ItemMast.php">Item M</a>&nbsp;
<a href="contact.php">contact</a>
</b>
</nav>
</div>
<div id="content"> 
<main>

<!DOCTYPE html>
<html>
<head>
	<title>order views</title>
<style>
body {background-color:#b;
	color: black;
	text-align: center;
}

</style>

</head>
<body>
	<div>
		<form action="sale.php" method="POST">
			<h4>salesman Form</h4>
		<table table class="table " id="dev-table" style="width:100%">
	<tr>
<th>salesman_id</th>
<th>name</th>
<th>city</th>

</tr>
<tr>
<td><select name="salesman" id="">
<?php
	$c=mysqli_connect("localhost","root","","tesco");
	 $q1="select * from salesman";
	 $q2=mysqli_query($c,$q1);
	 while($rows=mysqli_fetch_assoc($q2)){
		echo "<option>".$rows['salesman_id']."</option>";
		
	 }
	
	?>
		</select></td>
	<td><input type="text"name="name"></td>
	<td><input type="text"name="city"></td>
	
	
</tr>
</table>
<button type="submit" name="add">Add</button>
<button type="submit" name="update">Update</button>
<button type="Reset">Reset</button>
<button type="submit" name="del">Delete</button>
</form>
</div>
<h4>Salesman List </h4>
<table table class="table " id="dev-table" style="width:100%; background-color:#B3C7E6;color:black;">
<tr>
<th>salesman_id</th>
<th>name</th>
<th>city</th>
<th>commission</th>
</tr>
<?php
$check=$_POST['select'];
$connection = mysqli_connect("localhost","root","","tesco");
$result= mysqli_query($connection,"SELECT * FROM salesman limit 10");
if (mysqli_num_rows($result)> 0) {
	
	while($row = mysqli_fetch_assoc($result)) {
		echo "<tr>";
		echo "<td>" . $row["salesman_id"]."</td>";
		echo "<td>" . $row["name"]."</td>";
		echo "<td>" . $row["city"]."</td>";
		echo "<td>" . $row["commission"]."</td>";
		echo "</tr>";
	}}


?>
</table>
	<br><br><br>
	</div>
<script>
var  h=document.getElementById("select");
h.onclick=function(){
	
	
	};
</script>

</body>
</html>


</main>
</div><br><br><br>
<footer>
<div id="footer">
<li><small> <p align="center"> copyright &copy 2016 Bytes supermarket<p></li></small>
<div id="ima"><li><img src="image\3.jpg" height="20px" width="22px">Tel:0704881573</li><br>
<li><img src="image\2.jpg" height="20px" width="22px">Facebook:Bytes supermarket</div>
<div id="ime"><li><img src="image\1.jpg" height="20px" width="22px">Instagram:@Bytes supermarket</li><br>
<li><img src="image\4.png" height="20px" width="22px">
<a href="https//www:bytescomputers855@gmail.com">Bytessupermarket@gmail.com</a></P>
</footer>
</footer>
</body>
</html>
