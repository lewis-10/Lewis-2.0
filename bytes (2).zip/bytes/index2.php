<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!DOCTYPE html>
<html>
<Head>

<title> Bytes supermarket</title>
<link rel="stylesheet" href="bytes.css">
</head>
<body>
<header>
<h1>Bytes supermarket</h1><br>
</header>
<div id="wrapper">
<nav>
<b><b><a href="bytes.php">Home</a>&nbsp;
<a href="Customers.php">Customers</a>&nbsp;
<a href="index2.php">Orders</a>&nbsp;
<a href="Salesman.php">Salesman</a>&nbsp;
<a href="ItemMast.php">Item M</a>&nbsp;
<a href="contact.php">contact</a>
</b>
</nav>
</div>
<div id="content"> 
<main>
<head>
	<title>order views</title>
<style>
body {
	color: black;
	text-align: center;
}
</style>

</head>
<body>
	<div>
		<form action="order.php" method="POST">
			<h4>Customer Order Form</h4>
			<table class="table table-hover" id="dev-table" style="width:100%", font-color="black"  >
			<thead>
	<tr>
<th>ord_no</th>
<th> items Name</th>
<th>Number of items</th>
<th>ord_date</th>
<th>customer_id</th>
<th>salesman_id</th>
</tr>
<thead>
<tr>
<td>	<select name="ord_no" id="">
	<?php
	$c=mysqli_connect("localhost","root","","tesco");
	 $q1="select * from orders";
	 $q2=mysqli_query($c,$q1);
	 while($rows=mysqli_fetch_assoc($q2)){
		echo "<option>".$rows['ord_no']."</option>";
	 }
	
	?>
	</td>
	</select>
	
<td>	<select name="iten" id="">
	<?php
	$c=mysqli_connect("localhost","root","","tesco");
	 $q1="select * from item_mast";
	 $q2=mysqli_query($c,$q1);
	 while($rows=mysqli_fetch_assoc($q2)){
		echo "<option>".$rows['PRO_NAME']."</option>";	
	 }
	?>
	</td>
	</select>
	<td><input type="text"name="items"></td>
	<td><input type="date"name="ord_date"></td>
	<td>
	<select name="customer_id" id="">
	<?php
	$c=mysqli_connect("localhost","root","","tesco");
	 $q1="select * from customer";
	 $q2=mysqli_query($c,$q1);
	 while($rows=mysqli_fetch_assoc($q2)){
		echo "<option>".$rows['customer_id']."</option>";
		
	 }
	
	?>
		</select>
	</td>
	<td>
	<select name="salesman_id" id="">
	<?php
	$c=mysqli_connect("localhost","root","","tesco");
	 $q1="select * from salesman";
	 $q2=mysqli_query($c,$q1);
	 while($rows=mysqli_fetch_assoc($q2)){
		echo "<option>".$rows['salesman_id']."</option>";
		
	 }
	?>
		</select>
	</td>
</tr>
</table>
<button type="submit" name="add">Add</button>
<button type="submit" name="update">Update</button>
<button type="Reset">Reset</button>
<button type="submit" name="del">Delete</button>
</form>
</div>
<h4>Orders List </h4>
<table class="table table-hover" id="dev-table" style="width:100%; background-color:#B3C7E6;color:black;">
<tr>
<th>ord_no</th>
<th>purch_amt</th>
<th>ord_date</th>
<th>customer_id</th>
<th>salesman_id</th>
</tr>
<?php
error_reporting(0);
$check=$_POST['select'];
$connection = mysqli_connect("localhost","root","","tesco");
$result= mysqli_query($connection,"SELECT * FROM orders limit 10");
if (mysqli_num_rows($result)> 0) {
	
	while($row = mysqli_fetch_assoc($result)) {
		echo "<tr>";
		echo "<td>" . $row["ord_no"]."</td>";
		echo "<td>" . $row["purch_amt"]."</td>";
		echo "<td>" . $row["ord_date"]."</td>";
		echo "<td>" . $row["customer_id"]."</td>";
		echo "<td>" . $row["salesman_id"]."</td>";
		echo "</tr>";
	}}


?>
</table>
	<br><br><br>
	</div>
<script>
var  h=document.getElementById("select");
h.onclick=function(){
	
	
	};
</script>
</main>
</div>
<footer>
<div id="footer">
<li><small> <p align="center"> copyright & copy 2019 Bytes supermarket<p></li></small>
<div id="ima"><li><img src="image\3.jpg" height="20px" width="22px">Tel:0704881573</li><br>
<li><img src="image\2.jpg" height="20px" width="22px">Facebook:Bytes supermarket</div>
<div id="ime"><li><img src="image\1.jpg" height="20px" width="22px">Instagram:@Bytes supermarket</li><br>
<li><img src="image\4.png" height="20px" width="22px">
<a href="https//www:bytescomputers855@gmail.com">Bytessupermarket@gmail.com</a></P></div>
</footer>
</body>
</html>