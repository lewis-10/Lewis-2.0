<?php
//conection to database
$conn=mysqli_connect("localhost","root","","tesco");
//check connection_aborted
  if($conn){	
  
	$ord_no=($_POST['ord_no']);
  $ord_date=($_POST['ord_date']);
  $customer_id=($_POST['customer_id']);
  $salesman_id=($_POST['salesman_id']);
  $nam=$_POST['iten'];
  
  //save the data into table
  if(isset($_POST['add'])){ 
	  $com=0;
	  $pur=0;
	  $no=$_POST['items'];
	 echo $nam;
	  $q1="select * from item_mast where PRO_NAME='$nam'";
	$q2=mysqli_query($conn,$q1);
	while($rows=mysqli_fetch_assoc($q2)){
		$com=$rows['PRO_COM']*$no;
		$pur=$rows['PRO_PRICE']*$no;
	}
	$trig="drop TRIGGER `addCom`";
	mysqli_query($conn,$trig);
	$tri="CREATE TRIGGER `addCom` AFTER INSERT ON `item_mast` FOR EACH ROW 
	 UPDATE `salesman` SET `commission`=$com WHERE salesman_id='$salesman_id'";
	mysqli_query($conn,$tri);
	 
	echo $tri;
	
 
  $qh="insert into orders(ord_no,purch_amt,ord_date,customer_id,salesman_id)
    VALUES(null,'$pur','$ord_date','$customer_id','$salesman_id')";
	 echo $qh;
	//process the querry
	$qhi=mysqli_query($conn,$qh);
	
	//
	if($qhi){
		header('Location:index2.php');
	}
	else{
		echo "query failed tp add Order";
}

}
if(isset($_POST['update'])){
$q = "UPDATE `orders` SET `ord_date`='$ord_date',`customer_id`=$customer_id ,`salesman_id`=$salesman_id WHERE `ord_no`='$ord_no'";
echo $q;
if (mysqli_query($conn, $q)) {
	header('Location:index2.php');

} else {
	
    echo "Error updating record: " . mysqli_error($conn);
}}
if(isset($_POST['del'])){
	$q = "DELETE FROM `orders` WHERE `ord_no`='$ord_no'";
echo $q;
	if (mysqli_query($conn, $q)) {
		header('Location:index2.php');
	
	} else {
		
		echo "Error updating record: " . mysqli_error($conn);
	}}
}
$conn->close();

?>