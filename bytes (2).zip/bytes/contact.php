<!DOCTYPE html>
<html>
<Head>
<title> Bytes supermarket</title>
<link rel="stylesheet" href="bytes.css">
</head>
<body>
<header>
<h1>Bytes supermarket</h1>
</header>
<div id="wrapper">
<nav>
<b><a href="bytes.php">Home</a>&nbsp;
<a href="Customers.php">Customers</a>&nbsp;
<a href="index2.php">Orders</a>&nbsp;
<a href="Salesman.php">Salesman</a>&nbsp;
<a href="contact.php">contact</a>
</b>
</nav>
</div>
<div id="content"> 
<main>
<h2>Contact Bytes supermarket Today</h2>
<ul>
<li>E-mail:Bytes supermarkets855@gmail.com</li>
<li>Phone No.:254+704881573</li>
</ul>
<h3>Contact US</h3>
<fieldset>
<form action="/action_page.php" target="_blank">
<legend>contact informaton</legend>
First Name:<input type="text" name="fname" id="fname" required=yes><br><br>
last Name:<input type="text" name="lname" id="lname" required=yes><br><br>
Email:<input type="text" name="email" id="email" required=yes><br><br>
</fieldset>
Comments:<br><textarea name="comments" id="comments" rows="4" cols="40"></textarea><br><br>
<input type="submit">
<input type="reset">
</form>
</main>
</div><br><br><br><br>
<footer>
<footer>
<div id="footer">
<li><small> <p align="center"> copyright &copy 2016 Bytes supermarket<p></li></small>
<div id="ima"><li><img src="image\3.jpg" height="20px" width="22px">Tel:0704881573</li><br>
<li><img src="image\2.jpg" height="20px" width="22px">Facebook:Bytes supermarket</div>
<div id="ime"><li><img src="image\1.jpg" height="20px" width="22px">Instagram:@Bytes supermarket</li><br>
<li><img src="image\4.png" height="20px" width="22px">
<a href="https//www:bytescomputers855@gmail.com">Bytessupermarket@gmail.com</a></P>
</footer>
</footer>
</body>
</html>